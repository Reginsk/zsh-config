# Some aliases to make your life with the Swift Package Manager faster ✌️

alias spi='swift package init'
alias spf='swift package fetch'
alias spu='swift package update'
alias spx='swift package generate-xcodeproj'
alias sps='swift package show-dependencies'
alias spd='swift package dump-package'
